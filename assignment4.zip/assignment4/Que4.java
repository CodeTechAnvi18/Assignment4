package com.assignment4;

import java.util.Scanner;

public class Que4 {
	
	private int rows;
    private int cols;
    private int[][] elements;

    public Que4(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        elements = new int[rows][cols]; 
    }

    public int getRows() {
        return rows;
    }

    public int getCols() {
        return cols;
    }

    public void setElement(int i, int j, int value) {
        if (i >= 0 && i < rows && j >= 0 && j < cols) {
            elements[i][j] = value;
        } else {
            System.out.println("Invalid indices.");
        }
    }

    public Que4 add(Que4 other) {
        if (this.rows != other.getRows() || this.cols != other.getCols()) {
            System.out.println("Matrices cannot be added.");
            return null;
        }

        Que4 result = new Que4(this.rows, this.cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.setElement(i, j, this.elements[i][j] + other.elements[i][j]);
            }
        }
        return result;
    }

    public void display() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(elements[i][j] + " ");
            }
            System.out.println();
        }
    }


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of rows for the first matrix: ");
        int rows1 = sc.nextInt();
        System.out.print("Enter the number of columns for the first matrix: ");
        int cols1 = sc.nextInt();
        Que4 matrix1 = new Que4(rows1, cols1);
        
        System.out.println("Enter elements for the first matrix:");
        for (int i = 0; i < rows1; i++) {
            for (int j = 0; j < cols1; j++) {
                matrix1.setElement(i, j, sc.nextInt());
            }
        }

        System.out.print("Enter the number of rows for the second matrix: ");
        int rows2 = sc.nextInt();
        System.out.print("Enter the number of columns for the second matrix: ");
        int cols2 = sc.nextInt();
        Que4 matrix2 = new Que4(rows2, cols2);
        
        System.out.println("Enter elements for the second matrix:");
        for (int i = 0; i < rows2; i++) {
            for (int j = 0; j < cols2; j++) {
                matrix2.setElement(i, j, sc.nextInt());
            }
        }

        System.out.println("First Matrix:");
        matrix1.display();
        System.out.println("Second Matrix:");
        matrix2.display();

        Que4 result = matrix1.add(matrix2);
        if (result != null) {
            System.out.println("Result of Matrix Addition:");
            result.display();
        }

	}

}
