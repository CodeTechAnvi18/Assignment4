package com.assignment4;

import java.util.Scanner;

public class Que2 {
	private double real;
    private double imaginary;

    public Que2(double real, double imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }

    public Que2 add(Que2 other) {
        return new Que2(this.real + other.real, this.imaginary + other.imaginary);
    }

    public Que2 subtract(Que2 other) {
        return new Que2(this.real - other.real, this.imaginary - other.imaginary);
    }

    public Que2 multiply(Que2 other) {
        return new Que2(
            this.real * other.real - this.imaginary * other.imaginary,
            this.real * other.imaginary + this.imaginary * other.real
        );
    }

    @Override
    public String toString() {
        return real + " + " + imaginary + "i";
    }

    public static Que2 inputComplexNumber(Scanner scanner) {
        System.out.print("Enter the real part: ");
        double real = scanner.nextDouble();
        System.out.print("Enter the imaginary part: ");
        double imaginary = scanner.nextDouble();
        return new Que2(real, imaginary);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the first complex number:");
        Que2 c1 = inputComplexNumber(sc);

        System.out.println("Enter the second complex number:");
        Que2 c2 = inputComplexNumber(sc);

        Que2 sum = c1.add(c2);
        Que2 difference = c1.subtract(c2);
        Que2 product = c1.multiply(c2);

        System.out.println("Sum: " + sum);
        System.out.println("Difference: " + difference);
        System.out.println("Product: " + product);

	}

}
