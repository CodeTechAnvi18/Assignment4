package com.assignment4;

public class Triangle {

		 private double sideA;
		    private double sideB;
		    private double sideC;

		    public Triangle(double a, double b, double c) {
		        this.sideA = a;
		        this.sideB = b;
		        this.sideC = c;
		    }

		    public double getPerimeter() {
		        return sideA + sideB + sideC;
		    }

		    public double getArea() {
		        double s = getPerimeter() / 2; 
		        return Math.sqrt(s * (s - sideA) * (s - sideB) * (s - sideC));
		    }

		    public static void main(String[] args) {
		        Triangle triangle = new Triangle(3, 4, 5);
		        
		        System.out.println("Perimeter of the triangle: " + triangle.getPerimeter());
		        System.out.println("Area of the triangle: " + triangle.getArea());
	}

}
