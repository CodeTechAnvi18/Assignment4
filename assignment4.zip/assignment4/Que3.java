package com.assignment4;

import java.util.Scanner;

public class Que3 {
	private double salary;
    private int hoursWorked;

    public void getInfo(double salary, int hoursWorked) {
        this.salary = salary;
        this.hoursWorked = hoursWorked;
    }

    public void addSal() {
        if (salary < 500) {
            salary += 10; 
        }
    }

    public void addWork() {
        if (hoursWorked > 6) {
            salary += 5; 
        }
    }

    public double getFinalSalary() {
        return salary;
    }

	public static void main(String[] args) {
		
		 Scanner sc = new Scanner(System.in);

	        System.out.print("Enter the salary of the employee: ");
	        double salary = sc.nextDouble();

	        System.out.print("Enter the number of hours worked per day: ");
	        int hoursWorked = sc.nextInt();

	        Que3 employee = new Que3();
	        employee.getInfo(salary, hoursWorked);

	        employee.addSal();
	        employee.addWork();

	        System.out.println("Final Salary of the employee: $" + employee.getFinalSalary());

	}

}
